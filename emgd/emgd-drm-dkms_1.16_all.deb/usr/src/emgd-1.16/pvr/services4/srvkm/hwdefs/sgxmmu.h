/*************************************************************************/ /*!
@Title          SGX MMU defines
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@Description    Provides SGX MMU declarations and macros
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/ /**************************************************************************/

#if !defined(__SGXMMU_KM_H__)
#define __SGXMMU_KM_H__

/* to be implemented */

/* SGX MMU maps 4Kb pages */
#define SGX_MMU_PAGE_SHIFT				(12)
#define SGX_MMU_PAGE_SIZE				(1UL<<SGX_MMU_PAGE_SHIFT)
#define SGX_MMU_PAGE_MASK				(SGX_MMU_PAGE_SIZE - 1UL)

/* PD details */
#define SGX_MMU_PD_SHIFT				(10)
#define SGX_MMU_PD_SIZE					(1UL<<SGX_MMU_PD_SHIFT)
#define SGX_MMU_PD_MASK					(0xFFC00000UL)

/* PD Entry details */
#if defined(SGX_FEATURE_36BIT_MMU)
	#define SGX_MMU_PDE_ADDR_MASK			(0xFFFFFF00UL)
	#define SGX_MMU_PDE_ADDR_ALIGNSHIFT		(4)
#else
	#define SGX_MMU_PDE_ADDR_MASK			(0xFFFFF000UL)
	#define SGX_MMU_PDE_ADDR_ALIGNSHIFT		(0)
#endif
#define SGX_MMU_PDE_VALID				(0x00000001UL)
#define SGX_MMU_PDE_PAGE_SIZE_4K		(0x00000000UL)
#if defined(SGX_FEATURE_VARIABLE_MMU_PAGE_SIZE)
	#define SGX_MMU_PDE_PAGE_SIZE_16K		(0x00000002UL)
	#define SGX_MMU_PDE_PAGE_SIZE_64K		(0x00000004UL)
	#define SGX_MMU_PDE_PAGE_SIZE_256K		(0x00000006UL)
	#define SGX_MMU_PDE_PAGE_SIZE_1M		(0x00000008UL)
	#define SGX_MMU_PDE_PAGE_SIZE_4M		(0x0000000AUL)
	#define SGX_MMU_PDE_PAGE_SIZE_MASK		(0x0000000EUL)
#else
	#define SGX_MMU_PDE_WRITEONLY			(0x00000002UL)
	#define SGX_MMU_PDE_READONLY			(0x00000004UL)
	#define SGX_MMU_PDE_CACHECONSISTENT		(0x00000008UL)
	#define SGX_MMU_PDE_EDMPROTECT			(0x00000010UL)
#endif

/* PT details */
#define SGX_MMU_PT_SHIFT				(10)
#define SGX_MMU_PT_SIZE					(1UL<<SGX_MMU_PT_SHIFT)
#define SGX_MMU_PT_MASK					(0x003FF000UL)

/* PT Entry details */
#if defined(SGX_FEATURE_36BIT_MMU)
	#define SGX_MMU_PTE_ADDR_MASK			(0xFFFFFF00UL)
	#define SGX_MMU_PTE_ADDR_ALIGNSHIFT		(4)
#else
	#define SGX_MMU_PTE_ADDR_MASK			(0xFFFFF000UL)
	#define SGX_MMU_PTE_ADDR_ALIGNSHIFT		(0)
#endif
#define SGX_MMU_PTE_VALID				(0x00000001UL)
#define SGX_MMU_PTE_WRITEONLY			(0x00000002UL)
#define SGX_MMU_PTE_READONLY			(0x00000004UL)
#define SGX_MMU_PTE_CACHECONSISTENT		(0x00000008UL)
#define SGX_MMU_PTE_EDMPROTECT			(0x00000010UL)

#endif

/*****************************************************************************
 End of file (sgxmmu.h)
*****************************************************************************/
